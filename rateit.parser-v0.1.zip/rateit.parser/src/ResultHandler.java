import java.util.ListIterator;
import java.util.Vector;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class ResultHandler extends DefaultHandler {


	class PlayedSample {
		Integer id;
		Integer pos;
		Integer score;
		String comment;
	}

	class SessionTrial {
		Integer id;
		Vector<PlayedSample> psamples = new Vector<PlayedSample>();		
	}

	class MUSHRAEval {
		String expName;
		String filename;
		Integer currTrial;
		
		Vector<SessionTrial> strials = new Vector<SessionTrial>();
		
		Integer scores[][];
		String comments[][];
	}


	// Mushra Results
	
	MUSHRAEval me;
	Vector<MUSHRAEval> mes = new Vector<MUSHRAEval>();
	SessionTrial st;
	PlayedSample ps;
	TestHandler test;
	private String filename;
	
	ResultHandler(TestHandler test) {
		this.test = test;
	}
	
	 public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException{
		 int index;
		 
		 if(qName == "MUSHRAEval" && me == null) {
			 me = new MUSHRAEval();
			 me.filename = filename;
			 
			 if((index = attributes.getIndex("expName"))!=-1) {
				 me.expName = attributes.getValue(index);
				 if(!test.m.name.equals(me.expName))
					 throw new SAXException("Experiment names do not match.\n"+me.filename+":\t"+test.m.name+"!="+me.expName);
			 }
			 if((index = attributes.getIndex("currTrial"))!=-1) {
				me.currTrial = Integer.parseInt(attributes.getValue(index))+1;
				if(me.currTrial.intValue() != test.m.nbTrials)
					throw new SAXException("Experiment sizes do not match\n"+me.filename+":\t"+test.m.nbTrials+"!="+me.currTrial);
			 }	
			 
			 me.scores = new Integer[test.m.nbTrials][test.m.nbSamples];
			 me.comments = new String[test.m.nbTrials][test.m.nbSamples];
		 }
		 
		 else if(qName == "SessionTrial" && me != null && st == null) {
			 st = new SessionTrial();
			 
			 if((index = attributes.getIndex("id"))!=-1) {
				 st.id = Integer.decode(attributes.getValue(index));
			 }
		 }		 
		 else if(qName == "PlayedSample" && st != null && ps == null) {
			 ps = new PlayedSample();
			
			 if((index = attributes.getIndex("id"))!=-1) {
				 ps.id = Integer.decode(attributes.getValue(index));
			 }
			 if((index = attributes.getIndex("pos"))!=-1) {
				 ps.pos = Integer.decode(attributes.getValue(index));
			 }
			 if((index = attributes.getIndex("score"))!=-1) {
				 ps.score = Integer.decode(attributes.getValue(index));
			 }
			 
			 me.scores[st.id][ps.id] = ps.score;
		 }			 			
		 else {			
			 System.err.println("Unknown starting element:"+uri+"-"+localName+"-"+qName);
			 for(int i=0;i<attributes.getLength();i++) {
				 System.err.println("\t"+attributes.getLocalName(i)+"\t"+attributes.getValue(i));
			 }
		 }
	 }
	 
	 public void characters(char[] ch,
             int start,
             int length)
             throws SAXException
     {
		 String string = new String(ch, start, length).trim();
		 string = string.replace('\"', '\'');
		 string = string.replace('\n', ' ');
		 
		 if(string.length()==0)
			 return;
			 
		 if(me != null && st != null && ps != null) {
			 if(ps.comment == null)
				 ps.comment = string;
			 else
				 ps.comment += string;
			 me.comments [st.id][ps.id] = ps.comment;
		 }
		 else {
			 System.err.println("Unexpected characters:"+string);
		 }
		 
     }
             
	 public void endElement(String uri, String localName, String qName) {
		 
		 if(qName == "MUSHRAEval" && me != null && st == null & ps == null) {
			 mes.add(me);
			 me=null;
			 filename=null;
		 }
		 else if(qName == "SessionTrial" && me != null && st != null && ps == null) {
			 me.strials.add(st);
			 st=null;
		 }
		 else if(qName == "PlayedSample" && me != null && st != null && ps != null) {
			 st.psamples.add(ps);
			 ps=null;
		 }
		 else {
			 System.err.println("Unknown ending element:"+uri+"-"+localName+"-"+qName+"-");
		 }		 
	 }
	                 
	 public String toString() {
		 String result = "RESULTS OF A MUSHRA LISTENING TEST\n";
		 ListIterator<MUSHRAEval> li = mes.listIterator();
		 while(li.hasNext()) {
			 me = li.next();
			 result += "TRIAL NAME\t\""+me.expName + "\"\tRESULT FILENAME\t\"" + me.filename +"\"\n";
			 
			 result += "TRIAL";
			 for(int k=0;k<test.m.nbSamples;k++) 
				 result += "\tSCORE"+k+"\tCOMMENT"+k;
			 result += "\n";
					 
			 for(int i=0;i<me.currTrial;i++) {
				 result += i;
				 for(int j=0;j<test.m.nbSamples;j++) {
					 result += "\t"+me.scores[i][j];
					 if(me.comments[i][j]!=null)
						 result += "\t\"" + me.comments[i][j] + "\"";
					 else
						 result += "\t";
				 }
				 result += "\n";
			 }
			 result += "\n";
		 }			 
		 return result;
	 }

	void setFilename(String filename) {
		this.filename = filename;
	}
}
	
