import javax.xml.parsers.*;
import java.io.File;

public class Main {

	SAXParserFactory sf = SAXParserFactory.newInstance();
	TestHandler test = new TestHandler();
	ResultHandler results = new ResultHandler(test);
	
	Main(String[] args) throws Exception 
	{
		if(args.length!=2)
			usage();
		SAXParser p = sf.newSAXParser();
		p.parse(new File(args[0]),test);
		System.out.println(test.toString());

		for(int i=1;i<args.length;i++) {
			File f = new File(args[i]);
			if(f.isFile()) {
				results.setFilename(f.getName());
				p.parse(f,results);
			}
			else if(f.isDirectory()) {
				File files[] = f.listFiles();
				for(int j=0;j<files.length;j++) {
					if(files[j].isFile()) {
						results.setFilename(files[j].getName());
						p.parse(files[j],results);
					}
				}	
			}
		}
		System.out.println(results.toString());
	}

	void usage() {
		System.err.println("Usage: rateit.parser <xml test file>\n");
		System.exit(1);
	}

	void analyse() {
		double mean, var, std, min, max;
		int n;
		String comments;
		
		// calculating mean and variance of all	
		mean=0;
		var=0;
		min=Double.MAX_VALUE;
		max=Double.MIN_VALUE;
		for(int s=0;s<results.mes.size();s++) {
			ResultHandler.MUSHRAEval me = results.mes.get(s);		
			for(int i=0;i<test.m.nbTrials;i++) {
				for(int j=0;j<test.m.nbSamples;j++) {
					mean+=me.scores[i][j];
					var+=Math.pow(me.scores[i][j],2);
					if(me.scores[i][j]>max)
						max=me.scores[i][j];
					if(me.scores[i][j]<min)
						min=me.scores[i][j];
				}
			}
		}
		n = test.m.nbSamples*test.m.nbTrials*results.mes.size();
		std = Math.sqrt((var-Math.pow(mean,2)/n)/(n-1));
		mean /= n;
		System.out.println("CRITERIA\tMEAN\tSTD\tCOUNT\tMIN\tMAX\tCOMMENT");
		System.out.println("\"all\"\t"+mean+"\t"+std+"\t"+n+"\t"+min+"\t"+max+"\tNA");

		// calculating mean and variance per participant	
		for(int s=0;s<results.mes.size();s++) {
			ResultHandler.MUSHRAEval me = results.mes.get(s);		
			mean=0;
			var=0;
			min=Double.MAX_VALUE;
			max=Double.MIN_VALUE;
			comments="";

			for(int i=0;i<test.m.nbTrials;i++) {
				for(int j=0;j<test.m.nbSamples;j++) {
					mean+=me.scores[i][j];
					var+=Math.pow(me.scores[i][j],2);
					if(me.scores[i][j]>max)
						max=me.scores[i][j];
					if(me.scores[i][j]<min)
						min=me.scores[i][j];
					if(me.comments[i][j]!=null)
						comments+="\t\""+me.comments[i][j]+"\"";
				}
			}
			n = test.m.nbSamples*test.m.nbTrials;
			std = Math.sqrt((var-Math.pow(mean,2)/n)/(n-1));
			mean /= n;
			System.out.println("\""+me.filename+"\"\t"+mean+"\t"+std+"\t"+n+"\t"+min+"\t"+max+comments);
		}

		// calculating mean and variance per trial	
		for(int i=0;i<test.m.nbTrials;i++) {
			mean=0;
			var=0;
			min=Double.MAX_VALUE;
			max=Double.MIN_VALUE;
			comments="";
			
			for(int s=0;s<results.mes.size();s++) {
				ResultHandler.MUSHRAEval me = results.mes.get(s);		
				for(int j=0;j<test.m.nbSamples;j++) {
					mean+=me.scores[i][j];
					var+=Math.pow(me.scores[i][j],2);
					if(me.scores[i][j]>max)
						max=me.scores[i][j];
					if(me.scores[i][j]<min)
						min=me.scores[i][j];
					if(me.comments[i][j]!=null)
						comments+="\t\""+me.comments[i][j]+"\"";
				}
			}
			n = test.m.nbSamples*results.mes.size();
			std = Math.sqrt((var-Math.pow(mean,2)/n)/(n-1));
			mean /= n;
			System.out.println("\""+test.m.TrialName[i]+"\"\t"+mean+"\t"+std+"\t"+n+"\t"+min+"\t"+max+comments);
		}
		
		// calculating mean and variance per sample	
		for(int j=0;j<test.m.nbSamples;j++) {
			mean=0;
			var=0;
			min=Double.MAX_VALUE;
			max=Double.MIN_VALUE;
			comments="";
			
			for(int s=0;s<results.mes.size();s++) {
				ResultHandler.MUSHRAEval me = results.mes.get(s);		
				for(int i=0;i<test.m.nbTrials;i++) {
					mean+=me.scores[i][j];
					var+=Math.pow(me.scores[i][j],2);
					if(me.scores[i][j]>max)
						max=me.scores[i][j];
					if(me.scores[i][j]<min)
						min=me.scores[i][j];
					if(me.comments[i][j]!=null)
						comments+="\t\""+me.comments[i][j]+"\"";
				}
			}
			n = test.m.nbTrials*results.mes.size();
			std = Math.sqrt((var-Math.pow(mean,2)/n)/(n-1));
			mean /= n;
			System.out.println("\""+test.m.SampleFile[0][j]+"\"\t"+mean+"\t"+std+"\t"+n+"\t"+min+"\t"+max+comments);
		}

		// calculating mean and variance per sample+trial
		for(int j=0;j<test.m.nbSamples;j++) {
			for(int i=0;i<test.m.nbTrials;i++) {
				mean=0;
				var=0;
				min=Double.MAX_VALUE;
				max=Double.MIN_VALUE;
				comments="";
			
				for(int s=0;s<results.mes.size();s++) {
					ResultHandler.MUSHRAEval me = results.mes.get(s);		
					mean+=me.scores[i][j];
					var+=Math.pow(me.scores[i][j],2);
					if(me.scores[i][j]>max)
						max=me.scores[i][j];
					if(me.scores[i][j]<min)
						min=me.scores[i][j];
					if(me.comments[i][j]!=null)
						comments+="\t\""+me.comments[i][j]+"\"";
				}
				n = results.mes.size();
				std = Math.sqrt((var-Math.pow(mean,2)/n)/(n-1));
				mean /= n;
				System.out.println("\""+test.m.TrialName[i]+"+"+test.m.SampleFile[i][j]+"\"\t"+mean+"\t"+std+"\t"+n+"\t"+min+"\t"+max+comments);
			}
		}
		
		analyse2();
	}
	
	void analyse2() 
	{
		int sx=test.m.nbTrials;
		int sy=test.m.nbSamples;
		double[] mean1 = new double[sx*sy]; 
		double[] mean2 = new double[sx*sy]; 
		
		System.out.println("\nCONDITION\tCorrelation (R) between own ratings and mean scores\tCorrectly identified reference items [%]\tNumber of comments given");
		
		for(int s=0;s<results.mes.size();s++) {
			ResultHandler.MUSHRAEval me = results.mes.get(s);		
			for(int i=0;i<sx;i++) {
				 for(int j=0;j<sy;j++) {
					 mean1[i+j*sx]+=me.scores[i][j];
				 }
			 }
		}
		for(int i=0;i<sx;i++) {
			 for(int j=0;j<sy;j++) {
				 mean1[i+j*sx]/=results.mes.size();
			 }
		}
		for(int s=0;s<results.mes.size();s++) {
			ResultHandler.MUSHRAEval me = results.mes.get(s);
			double reference_ok = 0;
			int comments = 0;
			for(int i=0;i<sx;i++) {
				 for(int j=0;j<sy;j++) {
					 mean2[i+j*sx]=me.scores[i][j];
					 if(me.comments[i][j]!=null)
						 comments++;
				 }
				 int index = test.m.TrialReferenceIndex[i];
				 if(me.scores[i][index]==100)
					 reference_ok++;
			}
			reference_ok = reference_ok / sx * 100.;
			
			double c = correlation(mean1,mean2);
			System.out.println("\""+me.filename+"\"\t"+c+"\t"+reference_ok+"\t"+comments);
		}
	}
	
	double correlation(double scores1[], double scores2[])
	{
        double result = 0;
        double sum_sq_x = 0;
        double sum_sq_y = 0;
        double sum_coproduct = 0;
        double mean_x = scores1[0];
        double mean_y = scores2[0];
        for(int i=2;i<scores1.length+1;i+=1){
            double sweep =Double.valueOf(i-1)/i;
            double delta_x = scores1[i-1]-mean_x;
            double delta_y = scores2[i-1]-mean_y;
            sum_sq_x += delta_x * delta_x * sweep;
            sum_sq_y += delta_y * delta_y * sweep;
            sum_coproduct += delta_x * delta_y * sweep;
            mean_x += delta_x / i;
            mean_y += delta_y / i;
        }
        double pop_sd_x = (double) Math.sqrt(sum_sq_x/scores1.length);
        double pop_sd_y = (double) Math.sqrt(sum_sq_y/scores1.length);
        double cov_x_y = sum_coproduct / scores1.length;
        result = cov_x_y / (pop_sd_x*pop_sd_y);
        return result;        
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			new Main(args).analyse();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
