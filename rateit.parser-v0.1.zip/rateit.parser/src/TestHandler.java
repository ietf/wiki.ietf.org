import java.util.Vector;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;



public class TestHandler extends DefaultHandler {

	class Sample {
		String file;
		Boolean ref;
		Integer id;
	}

	class Trial {
		String name;
		Integer id;
		Vector<Sample> samples = new Vector<Sample>();
		
	}

	class MUSHRA {
		String name;
		Integer nbSamples;
		Integer nbTrials;
		String samplePath;
		
		Vector<Trial> trials = new Vector<Trial>();
		
		String TrialName[];	
		String SampleFile[][];
		Integer TrialReferenceIndex[];
	}


	// Mushra 
	
	MUSHRA m;
	Trial t;
	Sample s;
	
	 public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException{
		 int index;
		 
		 if(qName == "MUSHRA" && m == null) {
			 m = new MUSHRA();
			 
			 if((index = attributes.getIndex("name"))!=-1) {
				 m.name = attributes.getValue(index);
			 }
			 if((index = attributes.getIndex("nbSamples"))!=-1) {
					 m.nbSamples = Integer.decode(attributes.getValue(index));
			 }	
			 if((index = attributes.getIndex("nbTrials"))!=-1) {
				 m.nbTrials = Integer.decode(attributes.getValue(index));
			 }	
			 if((index = attributes.getIndex("samplePath"))!=-1) {
				 m.samplePath = attributes.getValue(index);
			 }
			 
			 m.TrialName = new String[m.nbTrials];
			 m.SampleFile = new String[m.nbTrials][m.nbSamples];
			 m.TrialReferenceIndex = new Integer[m.nbTrials];
		 }
		 
		 else if(qName == "Trial" && m != null && t == null) {
			 t = new Trial();
			 
			 if((index = attributes.getIndex("name"))!=-1) {
				 t.name = attributes.getValue(index);
			 }
			 if((index = attributes.getIndex("id"))!=-1) {
				 t.id = Integer.decode(attributes.getValue(index));
			 }
			 
			 m.TrialName[t.id] = t.name;
		 }		 
		 else if(qName == "Sample" && t != null && s == null) {
			 s = new Sample();
			
			 if((index = attributes.getIndex("file"))!=-1) {
				 s.file = attributes.getValue(index);
			 }
			 if((index = attributes.getIndex("ref"))!=-1) {
				 s.ref = Boolean.parseBoolean(attributes.getValue(index));
			 }
			 if((index = attributes.getIndex("id"))!=-1) {
				 s.id = Integer.decode(attributes.getValue(index));
			 }
			 
			 m.SampleFile[t.id][s.id] = s.file;
			 if(s.ref != null && s.ref==true)
				 m.TrialReferenceIndex[t.id]=s.id; 
		 }			 			
		 else {			
			 System.out.println(uri+"-"+localName+"-"+qName);
			 for(int i=0;i<attributes.getLength();i++) {
				 System.out.println("\t"+attributes.getLocalName(i)+"\t"+attributes.getValue(i));
			 }
		 }
	 }
	 
	 public void endElement(String uri, String localName, String qName) {
		 
		 if(qName == "MUSHRA" && m != null && t == null & s == null) {
			 //finished
		 }
		 else if(qName == "Trial" && m != null && t != null && s == null) {
			 m.trials.add(t);
			 t=null;
		 }
		 else if(qName == "Sample" && m != null && t != null && s != null) {
			 t.samples.add(s);
			 s=null;
		 }
		 else {
			 System.out.println("!"+uri+"-"+localName+"-"+qName+"-");
		 }		 
	 }
	                 
	 public String toString() {
		 String result = "DESCRIPTION OF MUSHRA LISTENING TESTS\n";
		 result += "NAME\t\""+m.name + "\"\tSAMPLE PATH\t\"" + m.samplePath + "\"\n";
		 
		 result += "TRIAL NAME\tTRIAL REFERENCE INDEX";
		 for(int j=0;j<m.nbSamples;j++) {
			 result += "\tFILE "+j;
		 }
		 result += "\n";
		 
		 for(int i=0;i<m.nbTrials;i++) {
			 result += "\""+m.TrialName[i]+"\"\t"+m.TrialReferenceIndex[i];
			 for(int j=0;j<m.nbSamples;j++) {
				 result += "\t\""+m.SampleFile[i][j]+"\"";
			 }
			 result += "\n";
		 }
		 result += "\n\f";
		 return result;
	 }
}
	
